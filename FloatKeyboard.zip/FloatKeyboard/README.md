# Float Keyboard

Keyboard (IME) with a small draggable floating box. Tap the box to show/hide a
resizable on-screen keyboard (Esc, F1-F12, full QWERTY, Ctrl/Alt/Shift/Win, arrows).
Keys send real key-down / key-up events, so held keys work in games and emulators.

## Build (no PC needed)
1. Create a new GitHub repo and upload everything in this folder (keep the
   `.github` folder).
2. Open the repo's **Actions** tab -> **Build APK** -> **Run workflow**.
3. When it finishes, download the `FloatKeyboard-debug` artifact, unzip it, install `app-debug.apk`.

## Build (Android Studio)
Open this folder, let Gradle sync, then Build > Build APK(s).

## Use
Open the app and follow steps 1-3. Sliders change keyboard size, opacity and box size.
In the keyboard bar: "Drag to move", "A-"/"A+" resize, "X" hides it.
Modifiers (Shift/Ctrl/Alt/Win) are one-shot: tap, then press the next key.
