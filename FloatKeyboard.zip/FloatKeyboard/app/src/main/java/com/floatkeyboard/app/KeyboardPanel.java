package com.floatkeyboard.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** The on-screen keyboard. Sends real key DOWN/UP events (good for games and emulators). */
public class KeyboardPanel extends LinearLayout {

    public interface Listener {
        void onKey(int code, boolean down, int repeat, int meta);
        void onClose();
        void onSize(int deltaPercent);
        void onDrag(int dx, int dy);
        void onDragEnd();
    }

    private static final String[] ROWS = {
        "Esc F1 F2 F3 F4 F5 F6 F7 F8 F9 F10 F11 F12",
        "` 1 2 3 4 5 6 7 8 9 0 - = Bksp",
        "Tab q w e r t y u i o p [ ] \\",
        "Caps a s d f g h j k l ; ' Enter",
        "Shift z x c v b n m , . / Up",
        "Ctrl Win Alt Space Left Down Right"
    };

    private static final int C_NORMAL = 0xFF3A3F47, C_PRESSED = 0xFF7C8B9B,
            C_LATCHED = 0xFF2E7D32, C_BAR = 0xFF22262B;

    private static class Key {
        String label;
        int code;
        float weight = 1f;
        boolean mod, letter, latched;
        TextView view;
        Runnable repeat;
        int count;
    }

    private final Listener listener;
    private final List<Key> keys = new ArrayList<>();
    private int scale = 100;
    private float dragX, dragY;

    public KeyboardPanel(Context c, Listener l) {
        super(c);
        listener = l;
        setOrientation(VERTICAL);
        setMotionEventSplittingEnabled(true);
        build();
    }

    public void setScale(int pct) {
        releaseAll();
        scale = pct;
        build();
    }

    /** Releases any held modifiers and stops key repeat. */
    public void releaseAll() {
        for (Key k : keys) {
            if (k.repeat != null) k.view.removeCallbacks(k.repeat);
            if (k.mod && k.latched) {
                k.latched = false;
                listener.onKey(k.code, false, 0, 0);
                k.view.setBackground(bg(C_NORMAL));
            }
        }
        refreshLabels();
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable bg(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(6));
        return g;
    }

    private void build() {
        keys.clear();
        removeAllViews();
        setPadding(dp(4), dp(4), dp(4), dp(4));
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(0xE6101418);
        panelBg.setCornerRadius(dp(10));
        setBackground(panelBg);

        addView(buildBar(), new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        int keyH = Math.max(dp(14), dp(32f * scale / 100f));
        for (String row : ROWS) {
            LinearLayout r = new LinearLayout(getContext());
            r.setOrientation(HORIZONTAL);
            r.setMotionEventSplittingEnabled(true);
            for (String token : row.split(" ")) {
                final Key k = makeKey(token);
                keys.add(k);
                LayoutParams lp = new LayoutParams(0, keyH, k.weight);
                lp.setMargins(dp(1.5f), dp(1.5f), dp(1.5f), dp(1.5f));
                r.addView(k.view, lp);
            }
            addView(r, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        }
    }

    private View buildBar() {
        LinearLayout bar = new LinearLayout(getContext());
        bar.setOrientation(HORIZONTAL);
        int h = dp(28);

        TextView drag = barButton("Drag to move");
        drag.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragX = e.getRawX();
                    dragY = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    listener.onDrag((int) (e.getRawX() - dragX), (int) (e.getRawY() - dragY));
                    dragX = e.getRawX();
                    dragY = e.getRawY();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    listener.onDragEnd();
                    return true;
            }
            return true;
        });
        bar.addView(drag, new LayoutParams(0, h, 1f));

        TextView minus = barButton("A-");
        minus.setOnClickListener(v -> listener.onSize(-10));
        bar.addView(minus, new LayoutParams(dp(48), h));

        TextView plus = barButton("A+");
        plus.setOnClickListener(v -> listener.onSize(10));
        bar.addView(plus, new LayoutParams(dp(48), h));

        TextView close = barButton("X");
        close.setOnClickListener(v -> listener.onClose());
        bar.addView(close, new LayoutParams(dp(48), h));
        return bar;
    }

    private TextView barButton(String text) {
        TextView t = new TextView(getContext());
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        t.setGravity(Gravity.CENTER);
        t.setBackground(bg(C_BAR));
        return t;
    }

    private Key makeKey(String token) {
        final Key k = new Key();
        k.label = token;
        switch (token) {
            case "Esc": k.code = KeyEvent.KEYCODE_ESCAPE; break;
            case "`": k.code = KeyEvent.KEYCODE_GRAVE; break;
            case "-": k.code = KeyEvent.KEYCODE_MINUS; break;
            case "=": k.code = KeyEvent.KEYCODE_EQUALS; break;
            case "[": k.code = KeyEvent.KEYCODE_LEFT_BRACKET; break;
            case "]": k.code = KeyEvent.KEYCODE_RIGHT_BRACKET; break;
            case "\\": k.code = KeyEvent.KEYCODE_BACKSLASH; k.weight = 1.5f; break;
            case ";": k.code = KeyEvent.KEYCODE_SEMICOLON; break;
            case "'": k.code = KeyEvent.KEYCODE_APOSTROPHE; break;
            case ",": k.code = KeyEvent.KEYCODE_COMMA; break;
            case ".": k.code = KeyEvent.KEYCODE_PERIOD; break;
            case "/": k.code = KeyEvent.KEYCODE_SLASH; break;
            case "Bksp": k.code = KeyEvent.KEYCODE_DEL; k.weight = 2f; break;
            case "Tab": k.code = KeyEvent.KEYCODE_TAB; k.weight = 1.5f; break;
            case "Caps": k.code = KeyEvent.KEYCODE_CAPS_LOCK; k.weight = 1.8f; break;
            case "Enter": k.code = KeyEvent.KEYCODE_ENTER; k.weight = 2.2f; break;
            case "Shift": k.code = KeyEvent.KEYCODE_SHIFT_LEFT; k.weight = 2.6f; k.mod = true; break;
            case "Ctrl": k.code = KeyEvent.KEYCODE_CTRL_LEFT; k.weight = 1.4f; k.mod = true; break;
            case "Alt": k.code = KeyEvent.KEYCODE_ALT_LEFT; k.weight = 1.4f; k.mod = true; break;
            case "Win": k.code = KeyEvent.KEYCODE_META_LEFT; k.weight = 1.2f; k.mod = true; break;
            case "Space": k.code = KeyEvent.KEYCODE_SPACE; k.weight = 5f; k.label = ""; break;
            case "Left": k.code = KeyEvent.KEYCODE_DPAD_LEFT; k.label = "\u2190"; break;
            case "Up": k.code = KeyEvent.KEYCODE_DPAD_UP; k.label = "\u2191"; break;
            case "Down": k.code = KeyEvent.KEYCODE_DPAD_DOWN; k.label = "\u2193"; break;
            case "Right": k.code = KeyEvent.KEYCODE_DPAD_RIGHT; k.label = "\u2192"; break;
            default:
                char c = token.charAt(0);
                if (token.length() == 1 && c >= 'a' && c <= 'z') {
                    k.code = KeyEvent.KEYCODE_A + (c - 'a');
                    k.letter = true;
                } else if (token.length() == 1 && c >= '0' && c <= '9') {
                    k.code = KeyEvent.KEYCODE_0 + (c - '0');
                } else if (c == 'F') {
                    k.code = KeyEvent.KEYCODE_F1 + (Integer.parseInt(token.substring(1)) - 1);
                }
        }

        TextView tv = new TextView(getContext());
        tv.setText(k.label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, Math.max(7f, 13f * scale / 100f));
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(true);
        tv.setBackground(bg(C_NORMAL));
        k.view = tv;

        k.repeat = new Runnable() {
            @Override public void run() {
                k.count++;
                listener.onKey(k.code, true, k.count, meta());
                k.view.postDelayed(this, 55);
            }
        };

        tv.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    press(k);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    release(k);
                    return true;
            }
            return true;
        });
        return k;
    }

    private void press(Key k) {
        k.view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        if (k.mod) {
            // Modifiers are one-shot: tap to hold, released automatically after the next key
            k.latched = !k.latched;
            listener.onKey(k.code, k.latched, 0, meta());
            k.view.setBackground(bg(k.latched ? C_LATCHED : C_NORMAL));
            refreshLabels();
            return;
        }
        k.view.setBackground(bg(C_PRESSED));
        k.count = 0;
        listener.onKey(k.code, true, 0, meta());
        k.view.postDelayed(k.repeat, 400);
    }

    private void release(Key k) {
        if (k.mod) return;
        k.view.removeCallbacks(k.repeat);
        listener.onKey(k.code, false, 0, meta());
        k.view.setBackground(bg(C_NORMAL));
        // auto-release one-shot modifiers after a normal key
        for (Key m : keys) {
            if (m.mod && m.latched) {
                m.latched = false;
                listener.onKey(m.code, false, 0, meta());
                m.view.setBackground(bg(C_NORMAL));
            }
        }
        refreshLabels();
    }

    private int meta() {
        int m = 0;
        for (Key k : keys) {
            if (!k.mod || !k.latched) continue;
            switch (k.code) {
                case KeyEvent.KEYCODE_SHIFT_LEFT: m |= KeyEvent.META_SHIFT_ON | KeyEvent.META_SHIFT_LEFT_ON; break;
                case KeyEvent.KEYCODE_CTRL_LEFT: m |= KeyEvent.META_CTRL_ON | KeyEvent.META_CTRL_LEFT_ON; break;
                case KeyEvent.KEYCODE_ALT_LEFT: m |= KeyEvent.META_ALT_ON | KeyEvent.META_ALT_LEFT_ON; break;
                case KeyEvent.KEYCODE_META_LEFT: m |= KeyEvent.META_META_ON | KeyEvent.META_META_LEFT_ON; break;
            }
        }
        return m;
    }

    private void refreshLabels() {
        boolean shift = false;
        for (Key k : keys) if (k.code == KeyEvent.KEYCODE_SHIFT_LEFT && k.latched) shift = true;
        for (Key k : keys) {
            if (k.letter) k.view.setText(shift ? k.label.toUpperCase() : k.label);
        }
    }
}
