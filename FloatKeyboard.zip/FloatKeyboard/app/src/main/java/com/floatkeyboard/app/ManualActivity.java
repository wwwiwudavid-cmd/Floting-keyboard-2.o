package com.floatkeyboard.app;

import android.app.Activity;
import android.graphics.Outline;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** "How to use" screen: one screenshot per step. */
public class ManualActivity extends Activity {

    private static final String[] TITLES = {
        "Step 1: Enable the keyboard",
        "Step 2: Allow display over other apps",
        "Step 3: Switch to Float Keyboard",
        "Choose PC or Phone layout",
        "Add a number row",
        "Keyboard size, opacity and box size",
        "Test your settings"
    };

    private static final int[] IMAGES = {
        R.drawable.manual_1, R.drawable.manual_2, R.drawable.manual_3, R.drawable.manual_4,
        R.drawable.manual_5, R.drawable.manual_6, R.drawable.manual_7
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Ui.PAGE_BG);
        page.addView(Ui.header(this, "How to use"),
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 56)));

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 14);
        root.setPadding(pad, pad, pad, Ui.dp(this, 24));
        sv.addView(root);
        page.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView intro = new TextView(this);
        intro.setText("Follow steps 1 to 3 once. Then tap the floating box to show or hide the keyboard.");
        intro.setTextSize(16f);
        intro.setTextColor(Ui.NAVY);
        root.addView(intro);

        final float radius = Ui.dp(this, 18);
        for (int i = 0; i < IMAGES.length; i++) {
            TextView t = new TextView(this);
            t.setText(TITLES[i]);
            t.setTextSize(18f);
            t.setTextColor(Ui.NAVY);
            t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tp.topMargin = Ui.dp(this, 22);
            tp.bottomMargin = Ui.dp(this, 8);
            root.addView(t, tp);

            ImageView img = new ImageView(this);
            img.setImageResource(IMAGES[i]);
            img.setAdjustViewBounds(true);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setClipToOutline(true);
            img.setElevation(Ui.dp(this, 3));
            img.setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View v, Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius);
                }
            });
            root.addView(img, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        setContentView(page);
    }
}
