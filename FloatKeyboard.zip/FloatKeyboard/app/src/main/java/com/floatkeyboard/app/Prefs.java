package com.floatkeyboard.app;

import android.content.Context;
import android.content.SharedPreferences;

class Prefs {
    static final String SCALE = "scale";   // keyboard size, percent (50-200)
    static final String ALPHA = "alpha";   // keyboard opacity, percent (30-100)
    static final String BUBBLE = "bubble"; // floating box size, dp (32-96)
    static final String BX = "bx", BY = "by", PX = "px", PY = "py";

    final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getSharedPreferences("fk", Context.MODE_PRIVATE);
    }

    int get(String k, int d) { return sp.getInt(k, d); }
    void set(String k, int v) { sp.edit().putInt(k, v).apply(); }
    void resetPositions() { sp.edit().remove(BX).remove(BY).remove(PX).remove(PY).apply(); }
}
