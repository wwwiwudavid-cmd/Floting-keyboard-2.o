package com.floatkeyboard.app;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.ImageView;

/**
 * Keyboard (IME) whose UI is a small floating box. Tap the box to show/hide the
 * keyboard panel. Both are overlay windows that never take focus, so the app
 * underneath (your emulator) keeps its input connection.
 */
public class FloatKeyboardIME extends InputMethodService
        implements KeyboardPanel.Listener, SharedPreferences.OnSharedPreferenceChangeListener {

    private static final int FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;

    private WindowManager wm;
    private Prefs prefs;
    private ImageView bubble;
    private WindowManager.LayoutParams bubbleLp, panelLp;
    private KeyboardPanel panel;
    private boolean bubbleOn, panelOn;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = new Prefs(this);
        prefs.sp.registerOnSharedPreferenceChangeListener(this);
        showBubble();
    }

    @Override public void onDestroy() {
        prefs.sp.unregisterOnSharedPreferenceChangeListener(this);
        hidePanel();
        hideBubble();
        super.onDestroy();
    }

    // No docked keyboard: our UI is the floating panel.
    @Override public boolean onEvaluateInputViewShown() { return false; }

    @Override public void onStartInput(EditorInfo attribute, boolean restarting) {
        super.onStartInput(attribute, restarting);
        showBubble(); // retry in case overlay permission was just granted
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        boolean reopen = panelOn;
        hidePanel();
        hideBubble();
        prefs.resetPositions();
        showBubble();
        if (reopen) showPanel();
    }

    // ---- helpers -------------------------------------------------------------------------

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private int type() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private Point screen() {
        Point p = new Point();
        wm.getDefaultDisplay().getRealSize(p);
        return p;
    }

    private boolean canOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }


    private static int clampRange(int v, int max) { return Math.max(0, Math.min(v, Math.max(0, max))); }

    // ---- floating box --------------------------------------------------------------------

    private void showBubble() {
        if (bubbleOn || !canOverlay()) return;
        int size = dp(prefs.get(Prefs.BUBBLE, 48));

        bubble = new ImageView(this);
        bubble.setImageResource(R.drawable.bubble_logo);
        bubble.setScaleType(ImageView.ScaleType.FIT_XY);
        bubble.setPadding(dp(2), dp(2), dp(2), dp(2));
        updateBubbleStyle();

        Point s = screen();
        bubbleLp = new WindowManager.LayoutParams(size, size, type(), FLAGS, PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = clampRange(prefs.get(Prefs.BX, s.x - size - dp(12)), s.x - size);
        bubbleLp.y = clampRange(prefs.get(Prefs.BY, s.y / 2), s.y - size);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;

            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = bubbleLp.x;
                        startY = bubbleLp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float mx = e.getRawX() - downX, my = e.getRawY() - downY;
                        if (!moved && Math.hypot(mx, my) > dp(6)) moved = true;
                        if (moved) {
                            Point sc = screen();
                            bubbleLp.x = clampRange(startX + (int) mx, sc.x - bubbleLp.width);
                            bubbleLp.y = clampRange(startY + (int) my, sc.y - bubbleLp.height);
                            wm.updateViewLayout(bubble, bubbleLp);
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        if (moved) {
                            prefs.set(Prefs.BX, bubbleLp.x);
                            prefs.set(Prefs.BY, bubbleLp.y);
                        } else {
                            togglePanel();
                        }
                        return true;
                }
                return true;
            }
        });

        try {
            wm.addView(bubble, bubbleLp);
            bubbleOn = true;
        } catch (Exception ignored) { }
    }

    private void updateBubbleStyle() {
        if (bubble == null) return;
        // thin frame around the logo: white when closed, green while the keyboard is open
        GradientDrawable g = new GradientDrawable();
        g.setColor(panelOn ? 0xFF2E7D32 : 0xFFFFFFFF);
        g.setCornerRadius(dp(prefs.get(Prefs.BUBBLE, 48)) * 0.24f);
        bubble.setBackground(g);
    }

    private void hideBubble() {
        if (bubbleOn) {
            try { wm.removeView(bubble); } catch (Exception ignored) { }
        }
        bubbleOn = false;
    }

    // ---- keyboard panel ------------------------------------------------------------------

    private void togglePanel() {
        if (panelOn) hidePanel(); else showPanel();
    }

    private void showPanel() {
        if (panelOn || !canOverlay()) return;
        int scale = prefs.get(Prefs.SCALE, 100);
        panel = new KeyboardPanel(this, this);
        panel.setConfig(scale, prefs.get(Prefs.LAYOUT, 0), prefs.get(Prefs.NUMROW, 1) == 1);

        Point s = screen();
        int w = Math.min(s.x, dp(520) * scale / 100);
        panelLp = new WindowManager.LayoutParams(w, WindowManager.LayoutParams.WRAP_CONTENT,
                type(), FLAGS, PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.alpha = prefs.get(Prefs.ALPHA, 90) / 100f;

        panel.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int h = panel.getMeasuredHeight();
        panelLp.x = clampRange(prefs.get(Prefs.PX, (s.x - w) / 2), s.x - w);
        panelLp.y = clampRange(prefs.get(Prefs.PY, s.y - h - dp(8)), s.y - h);

        try {
            wm.addView(panel, panelLp);
            panelOn = true;
        } catch (Exception ignored) { }
        updateBubbleStyle();
    }

    private void hidePanel() {
        if (panelOn) {
            panel.releaseAll();
            try { wm.removeView(panel); } catch (Exception ignored) { }
        }
        panelOn = false;
        updateBubbleStyle();
    }

    private void refreshPanel() {
        if (panelOn) {
            hidePanel();
            showPanel();
        }
    }

    // ---- KeyboardPanel.Listener ----------------------------------------------------------

    @Override public void onKey(int code, boolean down, int repeat, int meta) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        long now = SystemClock.uptimeMillis();
        ic.sendKeyEvent(new KeyEvent(now, now,
                down ? KeyEvent.ACTION_DOWN : KeyEvent.ACTION_UP,
                code, repeat, meta, KeyCharacterMap.VIRTUAL_KEYBOARD, 0,
                KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
    }

    @Override public void onText(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        KeyEvent[] events = KeyCharacterMap.load(KeyCharacterMap.VIRTUAL_KEYBOARD)
                .getEvents(s.toCharArray());
        if (events != null) {
            for (KeyEvent e : events) ic.sendKeyEvent(e);
        } else {
            ic.commitText(s, 1);
        }
    }

    @Override public void onToggleLayout() {
        prefs.set(Prefs.LAYOUT, 1 - prefs.get(Prefs.LAYOUT, 0)); // listener rebuilds the panel
    }

    @Override public void onClose() { hidePanel(); }

    @Override public void onSize(int delta) {
        int v = Math.max(50, Math.min(200, prefs.get(Prefs.SCALE, 100) + delta));
        prefs.set(Prefs.SCALE, v); // listener below rebuilds the panel
    }

    @Override public void onDrag(int dx, int dy) {
        if (!panelOn) return;
        Point s = screen();
        panelLp.x = clampRange(panelLp.x + dx, s.x - panelLp.width);
        panelLp.y = clampRange(panelLp.y + dy, s.y - panel.getHeight());
        wm.updateViewLayout(panel, panelLp);
    }

    @Override public void onDragEnd() {
        if (!panelOn) return;
        prefs.set(Prefs.PX, panelLp.x);
        prefs.set(Prefs.PY, panelLp.y);
    }

    @Override public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
        if (Prefs.SCALE.equals(key) || Prefs.ALPHA.equals(key)
                || Prefs.LAYOUT.equals(key) || Prefs.NUMROW.equals(key)) {
            refreshPanel();
        } else if (Prefs.BUBBLE.equals(key)) {
            hideBubble();
            showBubble();
        }
    }
}
