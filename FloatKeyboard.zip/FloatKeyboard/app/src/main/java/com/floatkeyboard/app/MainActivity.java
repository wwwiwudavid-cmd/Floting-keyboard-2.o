package com.floatkeyboard.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.SpannableString;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.text.style.ForegroundColorSpan;

public class MainActivity extends Activity {

    private static final String S1 = "1. Enable the keyboard";
    private static final String S2 = "2. Allow display over other apps";
    private static final String S3 = "3. Switch to Float Keyboard";

    private Prefs prefs;
    private Button step1, step2, step3;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Ui.PAGE_BG);
        page.addView(Ui.header(this, "Float Keyboard"),
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(24));
        sv.addView(root);
        page.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // ---- setup card ----
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.cardBg(this));
        card.setElevation(dp(4));
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        root.addView(card, lp(0));

        TextView title = text("Float Keyboard", 28f, Ui.NAVY, false);
        card.addView(title);
        TextView sub = text("Setup (do once, in order):", 16f, Ui.NAVY, false);
        sub.setPadding(0, dp(8), 0, dp(8));
        card.addView(sub);

        step1 = Ui.button(this, S1, v ->
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        card.addView(step1, lp(8));

        step2 = Ui.button(this, S2, v -> {
            if (Build.VERSION.SDK_INT >= 23) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        card.addView(step2, lp(8));

        step3 = Ui.button(this, S3, v ->
                ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());
        card.addView(step3, lp(8));

        TextView hint = text("After step 3 a small \"KB\" box floats on screen. Drag it anywhere; "
                + "tap it to show or hide the keyboard.", 15f, 0xFF3B4A6B, false);
        hint.setPadding(dp(4), dp(12), dp(4), 0);
        card.addView(hint);

        // ---- layout options ----
        final Button layoutBtn = Ui.button(this, layoutText(), null);
        layoutBtn.setOnClickListener(v -> {
            prefs.set(Prefs.LAYOUT, 1 - prefs.get(Prefs.LAYOUT, 0));
            layoutBtn.setText(layoutText());
        });
        root.addView(layoutBtn, lp(14));

        final Button numBtn = Ui.button(this, numText(), null);
        numBtn.setOnClickListener(v -> {
            prefs.set(Prefs.NUMROW, 1 - prefs.get(Prefs.NUMROW, 1));
            numBtn.setText(numText());
        });
        root.addView(numBtn, lp(10));

        // ---- sliders ----
        addSeek(root, "Keyboard size", Prefs.SCALE, 50, 200, 100, "%");
        addSeek(root, "Keyboard opacity", Prefs.ALPHA, 30, 100, 90, "%");
        addSeek(root, "Floating box size", Prefs.BUBBLE, 32, 96, 48, "dp");

        root.addView(Ui.button(this, "Reset box and keyboard positions",
                v -> prefs.resetPositions()), lp(14));

        TextView testLabel = text("Test field:", 16f, Ui.NAVY, false);
        testLabel.setPadding(dp(2), dp(16), 0, dp(6));
        root.addView(testLabel);

        EditText test = new EditText(this);
        test.setHint("Tap here to test the keyboard");
        test.setTextColor(Ui.NAVY);
        test.setBackground(Ui.rect(this, 0xFFFFFFFF, 14, Ui.BORDER));
        test.setPadding(dp(14), dp(12), dp(14), dp(12));
        root.addView(test, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(Ui.button(this, "How to use (manual)", v ->
                startActivity(new Intent(this, ManualActivity.class))), lp(22));

        setContentView(page);
    }

    @Override protected void onResume() {
        super.onResume();
        setStep(step1, S1, isEnabled());
        setStep(step2, S2, Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this));
        setStep(step3, S3, isDefault());
    }

    private boolean isEnabled() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        for (InputMethodInfo i : imm.getEnabledInputMethodList()) {
            if (i.getPackageName().equals(getPackageName())) return true;
        }
        return false;
    }

    private boolean isDefault() {
        String cur = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        return cur != null && cur.startsWith(getPackageName() + "/");
    }

    private void setStep(Button b, String label, boolean done) {
        SpannableString s = new SpannableString((done ? "\u2713  " : "") + label);
        if (done) s.setSpan(new ForegroundColorSpan(Ui.BLUE), 0, 1, 0);
        b.setText(s);
    }

    private String layoutText() {
        return "Layout: " + (prefs.get(Prefs.LAYOUT, 0) == 0 ? "PC (tap for Phone)" : "Phone (tap for PC)");
    }

    private String numText() {
        return "Phone layout number row: " + (prefs.get(Prefs.NUMROW, 1) == 1 ? "ON" : "OFF");
    }

    private int dp(int v) { return Ui.dp(this, v); }

    private LinearLayout.LayoutParams lp(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(topDp);
        return p;
    }

    private TextView text(String t, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return v;
    }

    private void addSeek(LinearLayout parent, final String name, final String key,
                         final int min, int max, int def, final String unit) {
        final TextView label = text(name + ": " + prefs.get(key, def) + unit, 16f, Ui.NAVY, false);
        label.setPadding(dp(2), dp(14), 0, 0);
        parent.addView(label);

        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(prefs.get(key, def) - min);
        sb.setProgressTintList(ColorStateList.valueOf(Ui.BLUE));
        sb.setThumbTintList(ColorStateList.valueOf(Ui.BLUE));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(0xFFD6E2FA));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                label.setText(name + ": " + (p + min) + unit);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) {
                prefs.set(key, s.getProgress() + min);
            }
        });
        parent.addView(sb);
    }
}
