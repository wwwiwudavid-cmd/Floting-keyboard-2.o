package com.floatkeyboard.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {

    private Prefs prefs;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("Float Keyboard");
        title.setTextSize(24);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Setup (do once, in order):");
        info.setPadding(0, dp(12), 0, dp(4));
        root.addView(info);

        addButton(root, "1. Enable the keyboard", v ->
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));

        addButton(root, "2. Allow display over other apps", v -> {
            if (Build.VERSION.SDK_INT >= 23) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        });

        addButton(root, "3. Switch to Float Keyboard", v ->
                ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());

        TextView hint = new TextView(this);
        hint.setText("\nAfter step 3 a small \"KB\" box floats on screen. Drag it anywhere; tap it to show or hide the keyboard.\n");
        root.addView(hint);

        final Button layoutBtn = new Button(this);
        layoutBtn.setAllCaps(false);
        layoutBtn.setText(layoutText());
        layoutBtn.setOnClickListener(v -> {
            prefs.set(Prefs.LAYOUT, 1 - prefs.get(Prefs.LAYOUT, 0));
            layoutBtn.setText(layoutText());
        });
        root.addView(layoutBtn);

        final Button numBtn = new Button(this);
        numBtn.setAllCaps(false);
        numBtn.setText(numText());
        numBtn.setOnClickListener(v -> {
            prefs.set(Prefs.NUMROW, 1 - prefs.get(Prefs.NUMROW, 1));
            numBtn.setText(numText());
        });
        root.addView(numBtn);

        addSeek(root, "Keyboard size", Prefs.SCALE, 50, 200, 100, "%");
        addSeek(root, "Keyboard opacity", Prefs.ALPHA, 30, 100, 90, "%");
        addSeek(root, "Floating box size", Prefs.BUBBLE, 32, 96, 48, "dp");

        addButton(root, "Reset box and keyboard positions", v -> prefs.resetPositions());

        TextView testLabel = new TextView(this);
        testLabel.setText("\nTest field:");
        root.addView(testLabel);
        root.addView(new EditText(this));

        setContentView(sv);
    }

    private String layoutText() {
        return "Layout: " + (prefs.get(Prefs.LAYOUT, 0) == 0 ? "PC (tap for Phone)" : "Phone (tap for PC)");
    }

    private String numText() {
        return "Phone layout number row: " + (prefs.get(Prefs.NUMROW, 1) == 1 ? "ON" : "OFF");
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void addButton(LinearLayout parent, String text, android.view.View.OnClickListener l) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setAllCaps(false);
        btn.setOnClickListener(l);
        parent.addView(btn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void addSeek(LinearLayout parent, String name, final String key,
                         final int min, int max, int def, final String unit) {
        final TextView label = new TextView(this);
        int cur = prefs.get(key, def);
        label.setText(name + ": " + cur + unit);
        label.setPadding(0, dp(8), 0, 0);
        parent.addView(label);

        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(cur - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                label.setText(name + ": " + (p + min) + unit);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) {
                prefs.set(key, s.getProgress() + min);
            }
        });
        parent.addView(sb);
    }
}
