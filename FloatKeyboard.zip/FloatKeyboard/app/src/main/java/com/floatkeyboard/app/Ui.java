package com.floatkeyboard.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/** Shared look: navy header, soft blue cards, rounded 3D buttons. */
final class Ui {
    static final int NAVY = 0xFF0B1F44;
    static final int BLUE = 0xFF2563EB;
    static final int BORDER = 0xFFC9D8F5;
    static final int PAGE_BG = 0xFFF3F6FC;
    static final int HEADER_L = 0xFF0A2A5E;
    static final int HEADER_R = 0xFF0B3C8E;

    private Ui() { }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rect(Context c, int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeColor != 0) g.setStroke(dp(c, 1), strokeColor);
        return g;
    }

    /** Button face with a darker bottom edge for a raised, 3D look. */
    private static Drawable face(Context c, int top, int bottom, int edge) {
        GradientDrawable shadow = rect(c, edge, 14, 0);
        GradientDrawable f = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{top, bottom});
        f.setCornerRadius(dp(c, 14));
        f.setStroke(dp(c, 1), BORDER);
        LayerDrawable l = new LayerDrawable(new Drawable[]{shadow, f});
        l.setLayerInset(1, 0, 0, 0, dp(c, 3));
        return l;
    }

    static Drawable buttonBg(Context c) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, rect(c, 0xFFDCE8FF, 14, BORDER));
        s.addState(new int[]{}, rect(c, 0xFFFFFFFF, 14, BORDER));
        return s;
    }

    static Button button(Context c, CharSequence text, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(NAVY);
        b.setTextSize(16f);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        b.setBackground(buttonBg(c));
        b.setStateListAnimator(null);
        b.setElevation(dp(c, 2));
        b.setMinHeight(dp(c, 52));
        b.setMinimumHeight(dp(c, 52));
        b.setOnClickListener(l);
        return b;
    }

    static TextView header(Context c, String title) {
        TextView t = new TextView(c);
        t.setText(title);
        t.setTextColor(Color.WHITE);
        t.setTextSize(20f);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(c, 18), 0, dp(c, 18), 0);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{HEADER_L, HEADER_R});
        t.setBackground(g);
        t.setElevation(dp(c, 4));
        return t;
    }

    static Drawable cardBg(Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFFEAF1FF, 0xFFF9FBFF});
        g.setCornerRadius(dp(c, 22));
        g.setStroke(dp(c, 1), 0xFFDCE6FA);
        return g;
    }
}
